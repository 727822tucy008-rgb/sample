package com.app.dao;

import com.app.model.User;
import com.app.util.DBUtil;
import com.app.util.LogUtil;
import javax.servlet.http.HttpServletRequest;
import java.sql.*;

public class UserDAO {

    public User authenticate(String username, String password, HttpServletRequest request) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ? AND is_verified = TRUE";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                User user = extractUser(rs);
                LogUtil.logAccess(username, "LOGIN_SUCCESS", request);
                return user;
            }

            LogUtil.logAccess(username, "LOGIN_FAILED", request);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean registerUser(User user, String verificationToken, HttpServletRequest request) {
        String checkSql = "SELECT COUNT(*) FROM users WHERE username = ? OR email = ?";
        String insertSql = "INSERT INTO users (username, email, password, verification_token) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkSql);
             PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {

            checkStmt.setString(1, user.getUsername());
            checkStmt.setString(2, user.getEmail());
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                LogUtil.logAccess(user.getUsername(), "SIGNUP_DUPLICATE", request);
                return false;
            }

            insertStmt.setString(1, user.getUsername());
            insertStmt.setString(2, user.getEmail());
            insertStmt.setString(3, user.getPassword());
            insertStmt.setString(4, verificationToken);

            int rows = insertStmt.executeUpdate();
            if (rows > 0) {
                LogUtil.logAccess(user.getUsername(), "SIGNUP_SUCCESS", request);
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            LogUtil.logAccess(user.getUsername(), "SIGNUP_ERROR", request);
        }
        return false;
    }

    public boolean verifyEmail(String token) {
        String sql = "UPDATE users SET is_verified = TRUE, verification_token = NULL WHERE verification_token = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, token);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private User extractUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setId(rs.getInt("id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setRole(rs.getString("role"));
        user.setVerified(rs.getBoolean("is_verified"));
        user.setVerificationToken(rs.getString("verification_token"));
        user.setCreatedAt(rs.getTimestamp("created_at"));
        return user;
    }
}