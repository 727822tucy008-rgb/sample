package com.app.servlet;

import com.app.dao.UserDAO;
import com.app.model.User;
import com.app.util.LogUtil;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class SignupServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/signup.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirm_password");

        if (!password.equals(confirmPassword)) {
            request.setAttribute("error", "Passwords do not match!");
            request.getRequestDispatcher("/signup.jsp").forward(request, response);
            return;
        }

        User user = new User(username, email, password);
        String verificationToken = LogUtil.generateVerificationToken();

        UserDAO userDAO = new UserDAO();
        boolean success = userDAO.registerUser(user, verificationToken, request);

        if (success) {
            String appUrl = request.getRequestURL().toString().replace(request.getServletPath(), "");
            String verifyLink = appUrl + "/verify?token=" + verificationToken;

            request.setAttribute("message", "Registration successful! Verify your email.");
            request.setAttribute("verifyLink", verifyLink);
            request.getRequestDispatcher("/verify.jsp").forward(request, response);
        } else {
            request.setAttribute("error", "Username or email already exists!");
            request.getRequestDispatcher("/signup.jsp").forward(request, response);
        }
    }
}