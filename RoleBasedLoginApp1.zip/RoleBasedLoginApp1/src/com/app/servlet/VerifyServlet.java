package com.app.servlet;

import com.app.dao.UserDAO;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class VerifyServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String token = request.getParameter("token");

        if (token != null && !token.isEmpty()) {
            UserDAO userDAO = new UserDAO();
            boolean verified = userDAO.verifyEmail(token);

            if (verified) {
                request.setAttribute("message", "Email verified successfully! You can now login.");
            } else {
                request.setAttribute("error", "Invalid or expired verification token!");
            }
        } else {
            request.setAttribute("error", "No verification token provided!");
        }

        request.getRequestDispatcher("/verify.jsp").forward(request, response);
    }
}