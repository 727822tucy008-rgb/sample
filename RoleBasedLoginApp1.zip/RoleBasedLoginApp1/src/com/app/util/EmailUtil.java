package com.app.util;

public class EmailUtil {
    public static void sendVerificationEmail(String toEmail, String verificationLink) {
        System.out.println("=== EMAIL VERIFICATION (DEMO) ===");
        System.out.println("To: " + toEmail);
        System.out.println("Link: " + verificationLink);
        System.out.println("In real application, implement email sending here");
    }
}