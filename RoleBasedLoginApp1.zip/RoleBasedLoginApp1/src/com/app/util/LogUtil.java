package com.app.util;

import javax.servlet.http.HttpServletRequest;
import java.sql.*;
import java.util.UUID;

public class LogUtil {

    public static void logAccess(String username, String action, HttpServletRequest request) {
        String sql = "INSERT INTO access_logs (username, action, ip_address, user_agent) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, username);
            pstmt.setString(2, action);
            pstmt.setString(3, getClientIP(request));
            pstmt.setString(4, request.getHeader("User-Agent"));
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static String getClientIP(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    public static String generateVerificationToken() {
        return UUID.randomUUID().toString();
    }
}