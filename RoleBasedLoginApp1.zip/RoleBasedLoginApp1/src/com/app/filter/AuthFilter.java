package com.app.filter;

import com.app.model.User;
import com.app.util.LogUtil;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class AuthFilter implements Filter {

    private ServletContext context;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        this.context = filterConfig.getServletContext();
        this.context.log("AuthenticationFilter initialized");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        String uri = req.getRequestURI();

        // Skip filter for public pages
        if (uri.endsWith("login.jsp") || uri.endsWith("signup.jsp") ||
                uri.endsWith("verify.jsp") || uri.endsWith("error.jsp") ||
                uri.contains("/login") || uri.contains("/signup") ||
                uri.contains("/verify") || uri.contains("/logout")) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);

        // Check if user is logged in
        if (session == null || session.getAttribute("user") == null) {
            if (uri.contains("/admin/") || uri.contains("/user/")) {
                LogUtil.logAccess("anonymous", "ACCESS_DENIED_" + uri, req);
                res.sendRedirect(req.getContextPath() + "/login.jsp");
                return;
            }
        } else {
            User user = (User) session.getAttribute("user");
            String role = user.getRole();

            // Role-based authorization
            if (uri.contains("/admin/")) {
                if (!"admin".equalsIgnoreCase(role)) {
                    LogUtil.logAccess(user.getUsername(), "ADMIN_ACCESS_DENIED", req);
                    req.setAttribute("error", "Access denied! Admin privileges required.");
                    req.getRequestDispatcher("/error.jsp").forward(request, response);
                    return;
                }
            }
        }

        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {
        // Cleanup
    }
}